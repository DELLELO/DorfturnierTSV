from django.urls import path
from . import views

app_name = "anmeldung"

urlpatterns = [
    path("", views.anmeldeformular, name="formular"),
    path("danke/", views.danke, name="danke"),
]
